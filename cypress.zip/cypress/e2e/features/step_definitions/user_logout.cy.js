import { Given, When, Then } from "@badeball/cypress-cucumber-preprocessor";
import Login_page from "../../pages/loginpage";
import product_page from "../../pages/productpage";
import { handleCypressError } from "../../../support/errorHandler";

Then('Verify the product page', ()=>{
    handleCypressError(product_page.addtocart_image(),"Product is not verified")


})

When('Click on the logout', ()=>{
handleCypressError(product_page.options_list(),"Exception in option list")
handleCypressError(product_page.logout(),"Page is not logged out")

})

Then('Verify logout properly', ()=>{
    handleCypressError(Login_page.verify_loginpage(), "Page is not logged out")



})
